package com.example.kalkulatorwalut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalkulatorwalutApplicationTests {

	@Test
	void contextLoads() {
	}

}
